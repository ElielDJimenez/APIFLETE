# Flete API para Render

### Instrucciones para desplegar sin GitHub

1. Ve a https://render.com y crea una cuenta.
2. Haz clic en "New" > "Web Service".
3. Elige "Deploy from Blueprint ZIP".
4. Sube este ZIP.
5. Render generará una URL como https://tu-api.onrender.com/flete

Puedes probarla con:
https://TU-URL.onrender.com/flete?origen=CNCAN&destino=DOCAU&contenedor=container40